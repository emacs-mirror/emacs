;; -*- no-byte-compile: t -*-

(define-package "multi-file" "0.2.3" "Example of a multi-file tar package" nil
  :url "http://puddles.li")
